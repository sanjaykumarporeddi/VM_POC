using Xunit;
using SalesSummary_POC.Services;
using Microsoft.Extensions.Logging;
using Moq;
using SalesSummary_POC.Models;
using System.Globalization;

namespace SalesSummary_POC.Tests
{
    public class SalesDataParserTests
    {
        private readonly Mock<ILogger<SalesDataParser>> _loggerMock;
        private readonly SalesDataParser _parser;

        public SalesDataParserTests()
        {
            _loggerMock = new Mock<ILogger<SalesDataParser>>();
            _parser = new SalesDataParser(_loggerMock.Object);
        }

        [Fact]
        public void Parse_ValidLine_ReturnsSalesData()
        {
            string line = "Segment,Country,Product,DiscountBand,100,�10.00,�20.00,01/01/2023";

            SalesData result = _parser.Parse(line);

            Assert.NotNull(result);
            Assert.Equal("Segment", result.Segment);
        }

        [Fact]
        public void Parse_InvalidLine_ReturnsNullAndLogsError()
        {
            string line = "Invalid Data";

            SalesData result = _parser.Parse(line);

            Assert.Null(result);
            _loggerMock.Verify(
                x => x.Log(
                    LogLevel.Warning,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => true),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.AtLeastOnce);
        }

        [Fact]
        public void Parse_EmptyLine_ReturnsNullAndLogsWarning()
        {
            string line = "";

            SalesData result = _parser.Parse(line);

            Assert.Null(result);
            _loggerMock.Verify(
                x => x.Log(
                    LogLevel.Warning,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => o.ToString().Contains("Skipping empty line.")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.Once);
        }
    }
}