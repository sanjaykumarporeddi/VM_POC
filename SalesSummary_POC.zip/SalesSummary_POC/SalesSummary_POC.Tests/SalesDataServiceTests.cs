﻿using Xunit;
using SalesSummary_POC.Services;
using Microsoft.Extensions.Logging;
using Moq;
using SalesSummary_POC.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.IO;

namespace SalesSummary_POC.Tests
{
    public class SalesDataServiceTests
    {
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<IWebHostEnvironment> _webHostEnvironmentMock;
        private readonly Mock<ILogger<SalesDataService>> _loggerMock;
        private readonly Mock<IDataSource> _dataSourceMock;
        private readonly Mock<IDataParser> _dataParserMock;
        private readonly SalesDataService _salesDataService;

        public SalesDataServiceTests()
        {
            _configurationMock = new Mock<IConfiguration>();
            _webHostEnvironmentMock = new Mock<IWebHostEnvironment>();
            _loggerMock = new Mock<ILogger<SalesDataService>>();
            _dataSourceMock = new Mock<IDataSource>();
            _dataParserMock = new Mock<IDataParser>();

            // Setup Configuration Mock (required for file paths etc.)
            _configurationMock.Setup(c => c["InvalidDataFileName"]).Returns("InvalidData.csv");

            // Setup WebHostEnvironment Mock (required for content root path)
            _webHostEnvironmentMock.Setup(w => w.ContentRootPath).Returns(Path.GetTempPath());  // Or a more suitable test path

            _salesDataService = new SalesDataService(
                _configurationMock.Object,
                _webHostEnvironmentMock.Object,
                _loggerMock.Object,
                _dataSourceMock.Object,
                _dataParserMock.Object
            );
        }

        [Fact]
        public async Task GetDataAsync_ReturnsData()
        {
            string filePath = "test.csv";
            var lines = new List<string> { "header", "Segment,Country,Product,DiscountBand,100,£10.00,£20.00,01/01/2023" };
            var salesData = new SalesData
            {
                Segment = "Segment",
                Country = "Country",
                Product = "Product",
                DiscountBand = "DiscountBand",
                UnitsSold = 100,
                ManufacturingPrice = 10.00m,
                SalePrice = 20.00m,
                Date = new DateTime(2023, 1, 1)
            };

            _dataSourceMock.Setup(d => d.ReadLinesAsync(filePath)).ReturnsAsync(lines);
            _dataParserMock.Setup(p => p.Parse(lines[1])).Returns(salesData);

            List<SalesData> result = await _salesDataService.GetDataAsync(filePath);

            Assert.NotNull(result);
            Assert.NotEmpty(result);
        }

        [Fact]
        public async Task GetDataAsync_HandlesParserError()
        {
            string filePath = "test.csv";
            var lines = new List<string> { "header", "invalid data" };

            _dataSourceMock.Setup(d => d.ReadLinesAsync(filePath)).ReturnsAsync(lines);
            _dataParserMock.Setup(p => p.Parse(lines[1])).Returns((SalesData)null);

            List<SalesData> result = await _salesDataService.GetDataAsync(filePath);

            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetDataAsync_HandlesDataSourceException()
        {
            string filePath = "test.csv";
            _dataSourceMock.Setup(d => d.ReadLinesAsync(filePath)).ThrowsAsync(new IOException("Simulated IO Exception"));

            List<SalesData> result = await _salesDataService.GetDataAsync(filePath);

            Assert.NotNull(result);
            Assert.Empty(result);
        }
    }
}