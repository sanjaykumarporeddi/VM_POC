﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SalesSummary_POC.Models;
using SalesSummary_POC.Services;
using System.Diagnostics;
using System.Globalization;

namespace SalesSummary_POC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ISalesDataService _salesDataService;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(ISalesDataService salesDataService, IWebHostEnvironment webHostEnvironment, ILogger<HomeController> logger, IConfiguration configuration)
        {
            _salesDataService = salesDataService;
            _webHostEnvironment = webHostEnvironment;
            _logger = logger;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string sortColumn, string sortOrder, int page = 1, int pageSize = 10)
        {
            string filePath = Path.Combine(_webHostEnvironment.ContentRootPath, _configuration["DataFilePath"] ?? "Data.csv");
            string currencyCultureName = _configuration["CurrencyCulture"] ?? "en-GB";
            string dateFormat = _configuration["DateFormat"] ?? "dd/MM/yyyy";

            try
            {
                var salesData = await _salesDataService.GetDataAsync(filePath);
                var salesDataViewModel = salesData.Select(data => new SalesDataViewModel(data, currencyCultureName, dateFormat)).ToList();

                if (!string.IsNullOrEmpty(sortColumn))
                {
                    ViewBag.SortColumn = sortColumn;
                    ViewBag.SortOrder = sortOrder;

                    Dictionary<string, Func<SalesDataViewModel, object>> sortOptions = new Dictionary<string, Func<SalesDataViewModel, object>>(StringComparer.OrdinalIgnoreCase)
                    {
                        {"segment", x => x.Segment},
                        {"country", x => x.Country},
                        {"product", x => x.Product},
                        {"unitssold", x => x.UnitsSold},
                        {"manufacturingprice", x => decimal.Parse(x.ManufacturingPrice, NumberStyles.Currency, new CultureInfo(currencyCultureName))},
                        {"saleprice", x => decimal.Parse(x.SalePrice, NumberStyles.Currency, new CultureInfo(currencyCultureName))},
                        {"date", x => DateTime.ParseExact(x.Date, dateFormat, CultureInfo.InvariantCulture)}
                    };

                    salesDataViewModel = sortOptions.ContainsKey(sortColumn)
                        ? (sortOrder == "asc"
                            ? salesDataViewModel.OrderBy(sortOptions[sortColumn]).ToList()
                            : salesDataViewModel.OrderByDescending(sortOptions[sortColumn]).ToList())
                        : salesDataViewModel.OrderBy(s => DateTime.ParseExact(s.Date, dateFormat, CultureInfo.InvariantCulture)).ToList();

                    ViewBag.SortOrder = sortOrder == "asc" ? "desc" : "asc";
                }
                else
                {
                    salesDataViewModel = salesDataViewModel.OrderBy(s => DateTime.ParseExact(s.Date, dateFormat, CultureInfo.InvariantCulture)).ToList();
                    ViewBag.SortColumn = "date";
                    ViewBag.SortOrder = "asc";
                }

                var pagedSalesData = salesDataViewModel.Skip((page - 1) * pageSize).Take(pageSize).ToList();
                ViewBag.TotalPages = (int)Math.Ceiling((double)salesDataViewModel.Count / pageSize);
                ViewBag.CurrentPage = page;
                ViewBag.PageSize = pageSize;

                return View(pagedSalesData);
            }
            catch (FileNotFoundException ex)
            {
                _logger.LogError(ex, "Data file not found: {FilePath}", filePath);
                ViewBag.ErrorMessage = "The data file could not be found. Please check the configuration.";
                return View("Error");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching sales data: {ErrorMessage}", ex.Message);
                ViewBag.ErrorMessage = "An unexpected error occurred while processing the sales data. Please try again later.";
                return View("Error");
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}