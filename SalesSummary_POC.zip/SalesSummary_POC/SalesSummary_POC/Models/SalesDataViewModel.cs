﻿using System.Globalization;
using System;

namespace SalesSummary_POC.Models
{
    public class SalesDataViewModel
    {
        public string? Segment { get; set; }
        public string? Country { get; set; }
        public string? Product { get; set; }
        public string? DiscountBand { get; set; }
        public double UnitsSold { get; set; }
        public string ManufacturingPrice { get; set; }
        public string SalePrice { get; set; }
        public string Date { get; set; }

        public SalesDataViewModel(SalesData data, string currencyCultureName, string dateFormat)
        {
            Segment = data.Segment;
            Country = data.Country;
            Product = data.Product;
            DiscountBand = data.DiscountBand;
            UnitsSold = data.UnitsSold;
            ManufacturingPrice = data.ManufacturingPrice.ToString("C", new CultureInfo(currencyCultureName));
            SalePrice = data.SalePrice.ToString("C", new CultureInfo(currencyCultureName));
            Date = data.Date.ToString(dateFormat);
        }
    }
}