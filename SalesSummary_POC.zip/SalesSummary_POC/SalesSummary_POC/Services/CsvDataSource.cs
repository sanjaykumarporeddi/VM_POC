﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace SalesSummary_POC.Services
{
    public class CsvDataSource : IDataSource
    {
        private readonly ILogger<CsvDataSource> _logger;

        public CsvDataSource(ILogger<CsvDataSource> logger)
        {
            _logger = logger;
        }

        public async Task<List<string>> ReadLinesAsync(string filePath)
        {
            var lines = new List<string>();
            try
            {
                using (var reader = new StreamReader(filePath, Encoding.ASCII))
                {
                    while (!reader.EndOfStream)
                    {
                        lines.Add(await reader.ReadLineAsync());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading file: {FilePath}", filePath);
                throw;
            }
            return lines;
        }
    }
}