﻿namespace SalesSummary_POC.Services
{
    public interface IDataSource
    {
        Task<List<string>> ReadLinesAsync(string filePath);
    }
}