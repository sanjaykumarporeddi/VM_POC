﻿using SalesSummary_POC.Models;

namespace SalesSummary_POC.Services
{
    public interface ISalesDataService
    {
        Task<List<SalesData>> GetDataAsync(string filePath);
    }
}