﻿using Microsoft.Extensions.Logging;
using SalesSummary_POC.Models;
using System;
using System.Globalization;

namespace SalesSummary_POC.Services
{
    public class SalesDataParser : IDataParser
    {
        private readonly ILogger<SalesDataParser> _logger;

        public SalesDataParser(ILogger<SalesDataParser> logger)
        {
            _logger = logger;
        }

        public SalesData Parse(string line)
        {
            if (string.IsNullOrEmpty(line))
            {
                _logger.LogWarning("Skipping empty line.");
                return null;
            }

            var values = line.Split(',');

            if (values.Length != 8)
            {
                _logger.LogWarning($"Skipping invalid row: {line} - Incorrect number of columns. Expected 8, got {values.Length}.");
                return null;
            }

            return new SalesData
            {
                Segment = ParseString(values[0], "Segment", line),
                Country = ParseString(values[1], "Country", line),
                Product = ParseString(values[2], "Product", line),
                DiscountBand = ParseString(values[3], "DiscountBand", line),
                UnitsSold = ParseUnitsSold(values[4], line),
                ManufacturingPrice = ParseCurrency(values[5], "ManufacturingPrice", line),
                SalePrice = ParseCurrency(values[6], "SalePrice", line),
                Date = ParseDate(values[7], line)
            };
        }

        private string ParseString(string value, string propertyName, string line) =>
            string.IsNullOrWhiteSpace(value) ? LogAndReturnNull(propertyName, line) : value.Trim();

        private double ParseUnitsSold(string value, string line)
        {
            try
            {
                double unitsSold = double.Parse(value.Trim(), CultureInfo.InvariantCulture);
                return unitsSold < 0 ? LogAndReturnInvalidUnits(line) : unitsSold;
            }
            catch (FormatException ex)
            {
                _logger.LogError($"Error parsing UnitsSold: {value}. Error: {ex.Message}");
                return -1;
            }
        }

        private decimal ParseCurrency(string value, string propertyName, string line)
        {
            try
            {
                string currencyString = value
                    .Replace("?", "£")
                    .Replace("\u00A0", "")
                    .Replace("\r", "")
                    .Replace("\n", "")
                    .Trim();

                CultureInfo enGB = new CultureInfo("en-GB");
                return decimal.Parse(currencyString, NumberStyles.Currency, enGB);
            }
            catch (FormatException ex)
            {
                _logger.LogError($"Error parsing {propertyName}: {value}. Error: {ex.Message}");
                return -1;
            }
        }

        private DateTime ParseDate(string value, string line)
        {
            try
            {
                return DateTime.ParseExact(value.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch (FormatException ex)
            {
                _logger.LogError($"Error parsing Date: {value}. Error: {ex.Message}");
                return DateTime.MinValue;
            }
        }

        private string LogAndReturnNull(string propertyName, string line)
        {
            _logger.LogWarning($"Skipping invalid row: {line} - {propertyName} is empty.");
            return null;
        }

        private double LogAndReturnInvalidUnits(string line)
        {
            _logger.LogWarning($"Skipping invalid row: {line} - UnitsSold cannot be negative.");
            return -1;
        }
    }
}