﻿using SalesSummary_POC.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesSummary_POC.Services
{
    public class SalesDataService : ISalesDataService
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly ILogger<SalesDataService> _logger;
        private readonly IDataSource _dataSource;
        private readonly IDataParser _dataParser;

        public SalesDataService(IConfiguration configuration, IWebHostEnvironment webHostEnvironment, ILogger<SalesDataService> logger, IDataSource dataSource, IDataParser dataParser)
        {
            _configuration = configuration;
            _webHostEnvironment = webHostEnvironment;
            _logger = logger;
            _dataSource = dataSource;
            _dataParser = dataParser;
        }

        public async Task<List<SalesData>> GetDataAsync(string filePath)
        {
            _logger.LogInformation($"Starting to read data from file: {filePath}");
            try
            {
                return await ReadAndParseDataAsync(filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error reading file: {ex.Message}");
                return new List<SalesData>();
            }
        }

        private async Task<List<SalesData>> ReadAndParseDataAsync(string filePath)
        {
            var salesData = new List<SalesData>();
            var invalidRows = new List<string>();

            List<string> lines = await _dataSource.ReadLinesAsync(filePath);
            string headerRow = lines.Count > 0 ? lines[0] : null;

            foreach (string line in lines.Skip(1).Where(l => !string.IsNullOrWhiteSpace(l)))
            {
                string originalLine = string.Copy(line);
                SalesData sales = null;
                string errorCode = null;

                try
                {
                    sales = _dataParser.Parse(line);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Error parsing line: {line}");
                    errorCode = "UnknownParsingError";
                }

                if (sales == null)
                {
                    errorCode ??= GetParseError(line.Split(','), originalLine);
                    invalidRows.Add($"\"{errorCode}\",\"{originalLine}\"");
                }
                else
                {
                    salesData.Add(sales);
                }
            }

            if (invalidRows.Any())
            {
                await WriteInvalidDataAsync(invalidRows, headerRow);
            }
            return salesData;
        }

        private async Task WriteInvalidDataAsync(List<string> invalidRows, string headerRow)
        {
            if (!invalidRows.Any()) return;

            string invalidDataFileName = _configuration["InvalidDataFileName"] ?? "InvalidData.csv";
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string invalidFileNameWithTimestamp = Path.GetFileNameWithoutExtension(invalidDataFileName) + "_" + timestamp + Path.GetExtension(invalidDataFileName);

            string invalidFilePath = Path.Combine(_webHostEnvironment.ContentRootPath, invalidFileNameWithTimestamp);
            List<string> outputLines = new List<string>();
            if (!string.IsNullOrEmpty(headerRow))
            {
                outputLines.Add($"ErrorType,{headerRow}");
            }
            outputLines.AddRange(invalidRows);
            await File.WriteAllLinesAsync(invalidFilePath, outputLines, Encoding.ASCII);
            _logger.LogWarning($"Wrote {invalidRows.Count} invalid rows to {invalidFilePath}");
        }

        private string GetParseError(string[] values, string originalLine)
        {
            if (values.Length != 8) return "IncorrectNumberOfColumns";

            string IsEmpty(string property, int index) =>
                string.IsNullOrWhiteSpace(values[index]) ? $"{property} cannot be empty" : null;

            string EmptyValidations = IsEmpty("Segment", 0) ??
                                      IsEmpty("Country", 1) ??
                                      IsEmpty("Product", 2) ??
                                      IsEmpty("DiscountBand", 3) ??
                                      IsEmpty("UnitsSold", 4) ??
                                      IsEmpty("ManufacturingPrice", 5) ??
                                      IsEmpty("SalePrice", 6) ??
                                      IsEmpty("Date", 7);

            if (!string.IsNullOrEmpty(EmptyValidations)) return EmptyValidations;

            try
            {
                string manufacturingPriceString = values[5].Replace("?", "£").Replace("\u00A0", "").Replace("\r", "").Replace("\n", "").Trim();
                decimal.Parse(manufacturingPriceString, NumberStyles.Currency, new CultureInfo("en-GB"));
            }
            catch (FormatException) { return "InvalidManufacturingPrice"; }

            try
            {
                double.Parse(values[4].Trim(), CultureInfo.InvariantCulture);
            }
            catch (FormatException) { return "InvalidUnitsSold"; }

            try
            {
                string salePriceString = values[6].Replace("?", "£").Replace("\u00A0", "").Replace("\r", "").Replace("\n", "").Trim();
                decimal.Parse(salePriceString, NumberStyles.Currency, new CultureInfo("en-GB"));
            }
            catch (FormatException) { return "InvalidSalePrice"; }

            try
            {
                DateTime.ParseExact(values[7].Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch (FormatException) { return "InvalidDate"; }

            return "UnknownParsingError";
        }
    }
}